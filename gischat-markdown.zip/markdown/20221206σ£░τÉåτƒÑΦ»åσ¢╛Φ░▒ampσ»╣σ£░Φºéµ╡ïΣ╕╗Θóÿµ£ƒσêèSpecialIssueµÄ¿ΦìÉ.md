![cover_image](https://mmbiz.qpic.cn/mmbiz_jpg/S9HsqSVeUqtb95sVq5Vo2hdHa5l4VghuJib98IhN7VKQXONRhUmo5cGib2icQM04ygraHCxIPoTKgZc41JXJPxPug/0?wx_fmt=jpeg)

#  地理知识图谱&对地观测主题期刊Special Issue推荐

原创  张喵喵  [ 城市感知计算 ](javascript:void\(0\);)

**城市感知计算**

微信号  sensingcity

功能介绍  认识世界和改造世界，分享地理信息系统科普知识与学术研究，欢迎加好友学术交流。

__ __

__ _ _ _ _

转发推荐  ** Transactions in GIS  ** 与  ** Remote  Sensing  ** 杂志最近推出的两期专刊
，分别关于地理知识图谱以及  地球对地观测  。

1  

![](https://mmbiz.qpic.cn/mmbiz_png/S9HsqSVeUqtb95sVq5Vo2hdHa5l4VghuicIvx9XnFJXXgArzibeAGRXPQUrhhFpRPIefbWpGFAnAKYIzuU7XdAPg/640?wx_fmt=png)

**征稿信息**

![](https://mmbiz.qpic.cn/mmbiz_gif/hByOOCRUvcSrJHfu34LQI1C4NJqw6UenicY46cWQ2ZxJdRrV50KRdyzmmWib9vBnIibtmDOTI9hFb7niadZ1rd2fQg/640?wx_fmt=gif)

随着近年来对地观测（EO）技术（如光学和微波遥感、LiDAR、GNSS和地理空间传感器网络）的井喷式发展，EO数据已经迅速积累到PB级，这为地球环境科学提供了最大的机遇，但同时也为这些EO大数据的处理带来了最大的挑战。由于人工智能（AI），特别是地理空间AI（GeoAI）方法和技术（如时空机器学习和深度学习）的发展和进步，EO大数据的建模、处理和分析已经达到了一个新的模式。通过整合EO大数据和GeoAI方法，对地球环境科学进行更全面和深入的研究成为可能。

本专刊旨在利用GeoAI和EO大数据对地球表面的水圈、岩石圈、生物圈和大气圈的物质、能量和信息进行方法论或应用研究。
规模可以是地方、区域或全球，但大规模和长时间序列的研究将被优先考虑。
此外，特别欢迎对高影响事件或灾害，如干旱、洪水、地震、海啸和火山爆发的关键主题指标的监测和分析研究。

![](https://mmbiz.qpic.cn/mmbiz_gif/hByOOCRUvcSrJHfu34LQI1C4NJqw6UenicY46cWQ2ZxJdRrV50KRdyzmmWib9vBnIibtmDOTI9hFb7niadZ1rd2fQg/640?wx_fmt=gif)

**该专刊希望讨论以下主题：**

（  1  ）  EO（如光学和微波遥感、LiDAR、GNSS和地理空间传感器网络）大数据的分析和挖掘。

（  2  ）  用于EO大数据建模/处理/分析的新型GeoAI模型和框架（例如，时空机器学习/深度学习）。

（  3  ）  检索环境变量（如降水、陆地/海洋表面温度、土壤湿度、气溶胶、植被指数、海冰浓度、海面盐度、雪盖、叶绿素a浓度）。

（  4  ）  环境变量监测和预测。

（  5  ）  环境变量检索的后处理（例如，多源数据融合、降尺度和图像修复）。

（  6  ）  从EO大数据中提取信息（例如，分类、分割、目标检测、动态监测和预测）。

（  7  ）  自然灾害（如干旱、洪水、内涝、野火、滑坡、浪涌地震、海啸和火山喷发）监测和评估。

（  8  ）  农作物产量估算。

（  9  ）  土地覆盖土地利用制图和情景预测。

（  10  ）  高影响事件的监测和分析（例如，流行病爆发、石油泄漏、天然气管道破裂、碳中和和排放高峰）。

**关键字：**  

•  Earth observation; big data; GeoAI; multisource/multimodal data fusion;
long time-series analysis; retrievals of environmental variables;
postprocessing of environmental variables retrievals; monitoring, evaluation,
and prediction; land cover land use; natural hazards; high-impact events

**接收投稿截稿时间**

** Manuscripts Due: 30/06/2023  **  

** **

**  
**

  
  

**客座编辑：**

‍  ‍  ‍  ‍  ‍  ‍  ‍  ‍  ‍  ‍  ‍  （1）黄敏博士, 江西师范大学地理与环境学院

（2）肖长江博士, 同济大学测绘与地理信息学院

（3）陈能成教授, 中国地质大学（武汉）地理信息系统国家工程研究中心

（4  ）  Dr. Runze L  i,  加州大学欧文分校土木与环境工程系

（5  ）Dr. Orhan Altan,  伊斯坦布尔技术大学地理信息学系

**投稿链接：** **
https://www.mdpi.com/journal/remotesensing/special_issues/FLT4P524M9  **

**  
**

2  

![](https://mmbiz.qpic.cn/mmbiz_png/S9HsqSVeUqtb95sVq5Vo2hdHa5l4VghuKpzGnd53YVnW0EWboELic3N1W6MB4Gg9PoE2oM0UVO3HxrzymgiadMLw/640?wx_fmt=png)

**征稿信息**

![](https://mmbiz.qpic.cn/mmbiz_gif/hByOOCRUvcSrJHfu34LQI1C4NJqw6UenicY46cWQ2ZxJdRrV50KRdyzmmWib9vBnIibtmDOTI9hFb7niadZ1rd2fQg/640?wx_fmt=gif)

随着地理大数据和人工智能的发展，知识图谱被引入GIS，将GIS推向一个新的阶段，即基于知识的GIS（K-GIS）。在20世纪80年代和90年代，本体论和专家系统被整合到GIS中，实现了地理知识的正式表示和推理。到21世纪初，遗憾的是，由于在表示和获取地理知识方面的局限性，当时的地理本体无法满足地理信息/专家系统的知识要求。近十年来，知识图谱作为一种大规模的知识库迅速发展，它起源于语义网络、本体论和语义网。

与传统的GIS不同，K-GIS由独立的地理知识库支持，是人机互动中的一种通用地理语言。自然语言和地图是人类主要的地理语言，它代表了具有确定时空特征和地理科学互动机制的地理知识。目前的知识图谱在地理概念、实体、属性和二元关系的知识表示方面很强大，这些知识是用机器学习方法从文本中提取的。在复杂地理知识的表示和获取方面也有进展，例如多种地理关系、时空过程和地理规则。然而，除了知识图谱和异质地理知识库的整合，各种知识表示方法仍然存在挑战。不同领域的地理知识库的构建和补充可能面临更多的问题，需要通过充分的人机协作来利用机器挖掘和专家知识。

K-GIS的基本功能包括但不限于：地理数据感知、地理信息理解、智能地理建模和地理科学问题解决。K-GIS的研究有助于推动地理大数据背景下的 "数据-知识-
模型
"协作范式，促进地理信息科学的变革性发展。K-GIS迫切需要从原有的计算技术向地理信息科学理论和实际应用转变。K-GIS的主要挑战在于以更友好的方式和高性能管理、分析、可视化相关的地理大数据、知识库和模型。K-GIS的见解将有助于支持地理信息服务向地理知识服务的转化。K-GIS的典型应用包括智能交通系统、智慧城市、自然灾害预防和缓解、自然资源管理、公共安全应急响应。

![](https://mmbiz.qpic.cn/mmbiz_gif/hByOOCRUvcSrJHfu34LQI1C4NJqw6UenicY46cWQ2ZxJdRrV50KRdyzmmWib9vBnIibtmDOTI9hFb7niadZ1rd2fQg/640?wx_fmt=gif)

**该专刊希望讨论以下主题：**

（  1  ）  K-GIS的基本理论和架构

（  2  ）  K-GIS的数据质量、元数据和标准

（  3  ）  K-GIS的人机合作开发

（  4  ）  K-GIS在全球变化中的综合和定量应用

（  5  ）  利用K-GIS实现可持续发展目标（SDG）的进展情况

（  6  ）  多模式的地理知识：表示、提取、管理、质量评估、推理和可视化

（  7  ）  领域地理知识库的构建

（  8  ）  地理知识库的共享

（  9  ）  基于知识的地理建模、地理空间分析和地理检索

（  10  ）  地理知识管理、问题回答和推荐系统

（  11  ）  地理知识在智能交通系统、智慧城市、自然灾害预防和缓解、自然资源管理、公共安全和应急响应等方面的应用。

**关键字：**  

•  K-GIS, Sustainable Development Goals (SDGs), representation, extraction,
management, quality evaluation, reasoning, and visualization, intelligent
transportation systems, smart cities, natural disaster prevention and
mitigation, natural resources management, public security

**接收投稿截稿时间**

** Abstracts Due: 15/02/2023  **  

** Approved Abstracts: 15/03/2023  ** ****

** Manuscripts Due: 31/08/2023  
Decision to Authors: 15/10/2023  
Final Papers Due: 31/12/2023  **

**  
**

  
  

**客座编辑：** ****

（1）周成虎教授  ,  中国科学院地理科学与资源研究所

（2  ）  张雪英教授, 南京师范大学地理科学学院

（3  ）  诸云强教授, 中国科学院地理科学与资源研究所

（4）黄伟明博士, 新加坡南洋理工大学计算机科学与工程学院

**投稿链接：** ** https://onlinelibrary.wiley.com/journal/14679671/homepage/call-
for-papers  ** ** **

预览时标签不可点

微信扫一扫  
关注该公众号





****



****



  收藏


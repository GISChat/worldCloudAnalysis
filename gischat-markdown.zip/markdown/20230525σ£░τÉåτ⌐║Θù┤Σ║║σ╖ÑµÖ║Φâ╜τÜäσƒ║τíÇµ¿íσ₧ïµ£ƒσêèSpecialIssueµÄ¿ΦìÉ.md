![cover_image](https://mmbiz.qpic.cn/mmbiz_jpg/S9HsqSVeUqtb95sVq5Vo2hdHa5l4VghuJib98IhN7VKQXONRhUmo5cGib2icQM04ygraHCxIPoTKgZc41JXJPxPug/0?wx_fmt=jpeg)

#  地理空间人工智能的基础模型期刊Special Issue推荐

原创  城市感知计算  [ 城市感知计算 ](javascript:void\(0\);)

**城市感知计算**

微信号  sensingcity

功能介绍  认识世界和改造世界，分享地理信息系统科普知识与学术研究，欢迎加好友学术交流。

__ __

__ _ _ _ _

转发推荐  ** International Journal of Geographical Information Science  **
杂志最近推出的专刊——  GeoFM：地理空间人工智能的基础模型。

![](https://mmbiz.qpic.cn/mmbiz_png/S9HsqSVeUqt7DV3DlhKic1MKFEJwllpjx15xDlKBPLL3NrI6vwuOXYxore8l2CLE0ia7dtkKQDOwT0uAoNUfus5w/640?wx_fmt=png)

**征稿信息**

![](https://mmbiz.qpic.cn/mmbiz_gif/hByOOCRUvcSrJHfu34LQI1C4NJqw6UenicY46cWQ2ZxJdRrV50KRdyzmmWib9vBnIibtmDOTI9hFb7niadZ1rd2fQg/640?wx_fmt=gif)

近年来人工智能（AI）和机器学习（ML）的快速发展对范式转变提出要求——越来越多的人工智能研究人员  倾向于在网络规模的数据上预先训练好的大型模型，
而不是为特定任务设计和训练  AI模  型  ，前者  可以通过微调、小样本学习或零样本学习来 "适应 "各种下游的任务。  这种预训练的模型也被称为
"基础模型"。  很好的例子是ChatGPT, LLaMA, GPT-4, Segment Anything Model, Stable
Diffusion等等。  其中有些模型只能应用于一种单一的数据模式--大型语言模型（如ChatGPT、LaMA），而其他模型（如GPT-4和Segment
Anything Model）可以利用多模态数据。
基础模型的发展可能成为这个十年的突破性创新，并有可能使整个社会接触到一种全新的信息检索、教育和数字援助方式。

之前的多项研究表明，当适应特定的任务时（例如常识性问题的回答），基础模型往往可以超越最先进的、完全监督的人工智能模型的性能。
然而，将基础模型应用于领域任务（如医疗诊断、地点推荐）会引发许多伦理问题（如用户和位置隐私、模型偏差等）。
现在，GIS科学和GeoAI的问题是，"基础模型是否会取代目前特定任务的GeoAI模型，从而引入一个通用的框架来解决地理空间问题？  "
如果是这样，程度如何，对GIS科学有什么影响？  如果不是，GIS科学和GeoAI研究人员可以为当前的新人工智能范式做出什么贡献？
无论答案如何，毫无疑问，我们已经进入了一个GeoAI的新时代，这需要新的研究实践、评估框架，以及对GIS科学界使用基础模型的伦理反思。
本专刊旨在汇集最新的研究，重点是应用、测试、修改和/或开发基础模型，以无缝处理涉及异质、多模态数据的不同地理空间任务，并产生更准确和公正的预测及生成结果。

![](https://mmbiz.qpic.cn/mmbiz_gif/hByOOCRUvcSrJHfu34LQI1C4NJqw6UenicY46cWQ2ZxJdRrV50KRdyzmmWib9vBnIibtmDOTI9hFb7niadZ1rd2fQg/640?wx_fmt=gif)

**该专刊希望讨论以下主题：**

  * 对地理空间应用基础模型的有效性进行基准测试 

  * 地理空间应用基础模型的新型提示工程方法 

  * 地理空间应用基础模型地质地基模型的 "零样本"和 "小样本"学习 

  * 在地理空间任务上对地理空间应用基础模型进行微调 

  * 为GeoAI应用开发（多模态）基础模型  ‍ 

  * 地理空间应用基础模型  的社会影响、风险和偏见 

  * 收集和整理大规模地理空间数据集，用于训练/调整/评估基础模型 

**讨论主题：**  

Benchmark the effectiveness of foundation models on geospatial applications;
Novel prompt engineering methods for geo-foundation models;  Zero-shot and
few-shot learning with geo-foundation models;  Fine-tuning foundation models
on geospatial tasks;  Development of (multimodal) foundation models for GeoAI
applications;  Societal impacts, risks, and biases of foundation models for
geospatial problems;  Endeavors in gathering and curating large-scale
geospatial datasets for training/finetuning/evaluating foundation models

时间节点  

** ** 摘要 (不超过250字) 提交: 2023年9月23日  ** **

** ** 摘要决定： ** 2023年9月30日  **  
** **

** ** 稿件全文提交: 2023年12月31日  ** **  

** ** 初步编辑决定  ： ** 2024年3月31日  **

** 稿件修改：2024年4月-5月  **

** 最终决定：2024年9月下旬（ ** 接受后几周内online，含DOI  ** ）  **

** 专刊出版：2024年12月下旬  **

** **

**  
**

  
  

**客座编辑：**

(1) Krzysztof Janowicz，维也纳大学和加州大学圣巴巴拉分校

krzysztof.janowicz@univie.ac.at

(2) 买庚辰，佐治亚大学 gengchen.mai25@uga.edu

(3) 朱睿，布里斯托大学 rui.zhu@bristol.ac.uk

(4) 黄伟明，南洋理工大学

weiming.huang@ntu.edu.sg

(5) Ni Lao，谷歌 nlao@google.com

(6) Ling Cai，IBM研究院 lingcai@ibm.com

注意事项

  

**  
**

  
  

有兴趣的作者应在2023年9月23日之前向Krzysztof Janowicz 和Gengchen Mai
(krzysztof.janowicz@univie.ac.at ;  gengchen.mai25@uga.edu) 提交  最多250字的
摘要。特邀编辑将审查提交的  ‍  ‍
摘要，并评估提交的内容是否符合本次专刊的主题。有合适主题的摘要作者将被邀请提交完整的手稿，但该邀请并不保证被专刊接受。

全文稿件，包括任何辅助材料，应在2023年12月31日之前通过该杂志的投稿门户（http://mc.manuscriptcentral.com/ijgis）提交，作者在投
‍  稿时应指定该专刊为目标。  请特别注意所需数据和代码的可用性声明。

** International Journal of Geographical Information Science  **
考虑所有稿件的严格条件是：稿件只提交给 ** International Journal of Geographical Information
Science  **
，未曾发表过，也没有在其他地方考虑发表或出版过。未能遵守这一条件的作者将被收取国际地理信息科学杂志为其论文所支付的所有费用，其论文将不会被发表。IJGIS实行双盲的同行评审。作者应只将匿名稿件存入在线保存库。IJGIS不考虑网上有作者信息的稿件。

**投稿链接：** ** https://think.taylorandfrancis.com/special_issues/geofm-
foundation-models-geospatial-artificial-intelligence  **

**  
**

预览时标签不可点

微信扫一扫  
关注该公众号





****



****



  收藏


![cover_image](https://mmbiz.qpic.cn/sz_mmbiz_jpg/yl9JFWBG20XRk7syoV4f5ACAyeVaWzicXStKng4o6ezgiaQiafIjPmuk4MekdIPEHuhDDZgrpKnb77RGmT9lmbibqw/0?wx_fmt=jpeg)

#  IJGIS 专刊征稿 | GeoHealth Data Science 

[ 城市感知计算 ](javascript:void\(0\);)

**城市感知计算**

微信号  sensingcity

功能介绍  认识世界和改造世界，分享地理信息系统科普知识与学术研究，欢迎加好友学术交流。

__ __

__ _ _ _ _

以下文章来源于CUHK太空与地球信息科学研究所  ，作者ISEIS

![](http://wx.qlogo.cn/mmhead/Q3auHgzwzM7aXQiagbbpEhOpxibRU6kvgtpz0Tlib3qmGf4zX8MxoChDQ/0)
**CUHK太空与地球信息科学研究所** .  香港中文大学太空与地球信息科学研究所研究生课程，公共讲座分享平台。

![](https://mmbiz.qpic.cn/sz_mmbiz_jpg/yl9JFWBG20XRk7syoV4f5ACAyeVaWzicXySzREB812QruL0ETZiaZF9LslXKGbpQB4W4y9Eq9WYw6sX2EuLZYdgA/640?wx_fmt=jpeg)

  

**IJGIS Special Issue**

**GeoHealth Data Science for Geographic Knowledge Discovery, Prediction and
Transfer in Health Research**

  

**Special Issue Editors**

Jiannan Cai

The Chinese University of Hong Kong

jncai@cuhk.edu.hk

  

Mei-Po Kwan

The Chinese University of Hong Kong

mpkwan@cuhk.edu.hk

  

Min Deng

Central South University

dengmin@csu.edu.cn

  

Shashi Shekhar

University of Minnesota

shekhar@umn.edu

  

Yiqun Xie

University of Maryland

xie@umd.edu

  

Due to rapid advancements in location-aware technologies (e.g., global
positioning system (GPS) trackers) and smart sensors (e.g., wearable
environmental and biomedical sensors), we now have unprecedented access to
vast amounts of highly accurate geospatial data relevant to human health and
disease. These geospatial data promise new spatial insights into the health
behaviors and outcomes of individuals, leading to a transformative shift
towards spatially-informed health research. Meanwhile, the multimodal data
sourced from different sensors also presents methodological challenges in
health research due to the high heterogeneity of data in terms of spatial-
temporal granularity, scale, structure, and semantics. The health data
revolution thus calls for a geospatial data science paradigm to explore new
forms of geographic knowledge underlying the complex formation and
transmission processes of diseases and health risks, as well as their
prediction and transfer involving space, time, and context.

  

The recent emerging geospatial data science techniques in artificial
intelligence (GeoAI), machine learning, and data mining have demonstrated
their ability to extract valuable geographic knowledge to support inferences
and decision-making from geospatial big data. However, current health research
largely applies existing data science methods without explicitly considering
the unique characteristics of geospatial data (e.g., spatial autocorrelation
and spatial heterogeneity). This oversight can limit or even bias health-
related geographic understanding and undermine the effectiveness of health
intervention policies. Furthermore, as human health and disease emerge as the
intricate result of the interplay among human behaviors, natural environments,
social contexts, and many other factors, the complex nature poses intrinsic
methodological challenges and necessitates innovative geospatial data science
methods.

  

This special issue seeks to **promote leveraging the geospatial data science
paradigm in advancing the geographic knowledge discovery, prediction, and
transfer in health research (geohealth data science)** . In particular, we
welcome submissions that focus on developing new spatially explicit data
science methods or innovatively improving state-of-the-art methods with
multimodal data sources to address methodological issues in existing health
research or explore new spatially-informed health research topics.

  

**Relevant Topics**

  

  

  * Novel theories and methods in geohealth data science 

  * Addressing methodological issues in geohealth research 

  * Perception, assessment, and early warning of health risks with novel geospatial datasets 

  * Spatiotemporal pattern detection of diseases and/or health risk factors 

  * Spatiotemporal association analysis and causal inference among diseases, human behaviors and health risk factors 

  * Spatiotemporal spread and prediction of infectious diseases 

  * Effects of human mobility on disease transmission 

  * Transferability of geohealth knowledge over space and time 

  

**Submission Procedure**

  

  

This IJGIS special issue welcomes submissions by scholars from all
disciplines. Interested authors should first submit a short abstract (250
words max) to **Jiannan Cai** (  jncai@cuhk.edu.hk  ), **Mei-Po Kwan** (
mpkwan@cuhk.edu.hk  ) and **Yiqun Xie** (  xie@umd.edu  ) before **January 24,
2024.** Guest editors will review the submitted abstracts and evaluate whether
the submissions fit the themes of this SI. Authors of abstracts with suitable
topics will be invited to submit full manuscripts, while the invitation does
not guarantee acceptance to the SI.

  

Full manuscripts, including any supporting materials, should be submitted
using the journal's  submission portal  by **April 30, 2024,** and the authors
should specify this SI as the target during their submission. Guidelines for
submission of full manuscripts can be found at:
http://www.tandfonline.com/action/authorSubmission?journalCode=tgis20&page=
instructions/.  Please pay special attention to the required data and codes
availability statement.

  

The _I_ _nternational Journal of Geographical Information Science_ considers
all manuscripts on the strict condition that they have been submitted only to
the International Journal of Geographical Information Science, that they have
not been published already, nor are they under consideration for publication
or in press elsewhere. Authors who fail to adhere to this condition will be
charged with all costs that the International Journal of Geographical
Information Science incurs for their papers, and their papers will not be
published. IJGIS exercises double-blinded peer reviews. Authors should only
deposit anonymous manuscripts to online depositories. IJGIS cannot consider
manuscripts with author information available online.

  

**Important Dates**

  

  

  * Abstracts (no more than 250 words) Due: Jan. 24, 2024 

  * Decisions on abstracts: Jan. 31, 2024 

  * Full manuscripts Due: Apr. 30, 2024 

![](https://mmbiz.qpic.cn/sz_mmbiz_jpg/yl9JFWBG20XRk7syoV4f5ACAyeVaWzicXia0zP9IGd4sic636Iiamz17uThvNubdepdASfH2wlDzutySxQnvY3fA1w/640?wx_fmt=jpeg)

**港中大太空所**

长按二维码识别关注

了解太空所最新信息

![](https://mmbiz.qpic.cn/sz_mmbiz_png/yl9JFWBG20XRk7syoV4f5ACAyeVaWzicXibFiadNc2T8eE6ibf2wDOsfibb0e66CeXpqRHSRqfw8wgcwLCslHbJIrSQ/640?wx_fmt=png)

  

预览时标签不可点

微信扫一扫  
关注该公众号





****



****



  收藏


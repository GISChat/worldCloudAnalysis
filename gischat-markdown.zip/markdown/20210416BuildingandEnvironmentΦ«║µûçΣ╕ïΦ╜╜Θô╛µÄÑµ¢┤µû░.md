![cover_image](https://mmbiz.qlogo.cn/mmbiz_jpg/S9HsqSVeUqtw2cdvGgUvmzmUtqUG1VicRNHwwvPtZXQ9Ffy6michKMfcExY9nKZ9asiaxgMz1G6XYD0T5IpOcicmfA/0?wx_fmt=jpeg)

#  Building and Environment论文下载链接更新

[ 城市感知计算 ](javascript:void\(0\);)

**城市感知计算**

微信号  sensingcity

功能介绍  认识世界和改造世界，分享地理信息系统科普知识与学术研究，欢迎加好友学术交流。

__ __

__ _ _ _ _

链接：https://pan.baidu.com/s/1IAA5y78sJuPz2mePsq2Caw

提取码：8zvm

  

上篇推文的文章下载地址不能用了，我重新上传了一份，下载链接进行更新。

  

预览时标签不可点

微信扫一扫  
关注该公众号





****



****



  收藏


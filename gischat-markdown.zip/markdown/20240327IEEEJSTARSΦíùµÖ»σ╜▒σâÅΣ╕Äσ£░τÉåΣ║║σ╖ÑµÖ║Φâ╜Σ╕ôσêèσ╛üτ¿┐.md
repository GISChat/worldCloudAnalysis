![cover_image](https://mmbiz.qpic.cn/sz_mmbiz_jpg/S9HsqSVeUqtTpn8ziaQJcP1m2BGT4S4FUwPPs0M9YicvTUicl0u8YxDibajoW5jvWI5K7MU0hVvaiaRoRdEIeLQKfNg/0?wx_fmt=jpeg)

#  IEEE J-STARS“街景影像与地理人工智能”专刊征稿

城市感知计算  [ 城市感知计算 ](javascript:void\(0\);)

**城市感知计算**

微信号  sensingcity

功能介绍  认识世界和改造世界，分享地理信息系统科普知识与学术研究，欢迎加好友学术交流。

__ __

__ _ _ _ _

《IEEE应用地球观测和遥感专题期刊》

IEEE Journal of Selected Topics in Applied Earth Observations and Remote
Sensing Special Issue on

专刊：  “  街景影像与地理人工智能  ”（Street View Imagery and GeoAI）

地理人工智能的出现和街景影像的大量涌现已经彻底改变了我们对城市微观环境的理解。与遥感影像数据不同，街景影像（不仅来自商业公司，还可能通过众包来源如社交媒体和志愿地理信息）提供了近景的视角，提供了对城市建成环境的详细、地面级的洞察。这些影像使研究人员能够对城市建成环境进行精细化、时间序列的分析。本专刊旨在探讨街景影像在城市分析中相对于传统遥感方法的独特优势。

本专刊旨在展示利用街景影像进行城市微观环境智能感知的创新研究。我们邀请应用地理人工智能方法解决各种城市问题的投稿。广泛的主题包括（但不限于）：

\-  城市功能区识别，从遥感影像的俯瞰视角和街景影像的近景视角共同观察；

\-  城市韧性，利用多源传感器和数据协同观察城市社区，以衡量面对灾害时的韧性差异；

\-  健康地理应用，如城市生态和绿地分析；

\-  城市安全感知，如对城市犯罪时空模式进行精细探索；

\-  智能交通，基于环境特征的交通模式评估，以改善城市流动性；

\-  文化遗产保护，利用时间序列影像记录和识别建筑环境变化；

\-  房地产分析，估计建筑年龄、风格、能源消耗和价值等。

本专刊关注城市近景影像和遥感影像的联合观测，文章至少使用一种影像数据。特别欢迎创新方法及对城市规划、政策制定和环境监测的实际影响的研究。

我们欢迎原创研究文章、综述、案例研究和技术报告，详细描述方法、数据分析和结果，突出在城市环境感知方面的实际应用和潜在影响。投稿应清晰阐明图像在城市研究中的重要性，并展示创新的分析技术。

** 日程安排  **

2024  年  6  月  1  日，投稿系统开放

2024  年  12  月  31  日，投稿系统关闭

** 格式  **

所有投稿将根据  IEEE  地球科学与遥感学会的指南进行同行评审。  提交的文章不得已在其他地方发表或正在审阅中。请在
http://mc.manuscriptcentral.com/jstars  上使用手稿中心界面提交您的稿件，并选择  “  街景图像与地理人工智能  ”
特刊稿件类型（  2024  年  6  月  1  日开放  ）。

** 客座编辑  **

张岩，香港中文大学，中国香港特别行政区（  yanzhang@cuhk.edu.hk  ）

关美宝，香港中文大学，中国香港特别行政区（  mpkwan@cuhk.edu.hk  ）

陈能成，中国地质大学（武汉），中国（  chennengcheng@cug.edu.cn  ）

Marco Helbich  ，乌特勒支大学，荷兰（  m.helbich@uu.nl  ）

王培晓，中国科学院地理科学与资源研究所，中国（  wpx@lreis.ac.cn  ）

![](https://mmbiz.qpic.cn/sz_mmbiz_png/S9HsqSVeUqtTpn8ziaQJcP1m2BGT4S4FUoKt4vQuQQlOrMkqa7Bt8DeCB2rFxQLnD7icxlC94Cj2VPoVFXnnmicsw/640?wx_fmt=png&from=appmsg)

  

预览时标签不可点

微信扫一扫  
关注该公众号





****



****



  收藏

精选留言


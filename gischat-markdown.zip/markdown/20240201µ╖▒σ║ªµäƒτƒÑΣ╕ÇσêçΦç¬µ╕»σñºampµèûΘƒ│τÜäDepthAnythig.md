![cover_image](https://mmbiz.qpic.cn/mmbiz_jpg/jicXQgEGWaibdebDZdxFvYPCbzoEXK1YjfejboKfm6W0EicUmcpgg2Gcc3tia10pbwtLIOLy476qiaItz6sh0rWnpDQ/0?wx_fmt=jpeg)

#  深度感知一切|自港大&抖音的DepthAnythig

[ 城市感知计算 ](javascript:void\(0\);)

**城市感知计算**

微信号  sensingcity

功能介绍  认识世界和改造世界，分享地理信息系统科普知识与学术研究，欢迎加好友学术交流。

__ __

__ _ _ _ _

编者荐语：

博主的同学，专注于遥感AI算法及应用的非盈利分享平台，欢迎关注。

以下文章来源于遥感新AI  ，作者遥感螺丝钉

![](http://wx.qlogo.cn/mmhead/OU2rqvx645vkoFUyd1bgqribcfGl1kbibYLa9mg40PCkMIxGfVs9gHvl2PBKwFuHj2e52v5ibxj6rk/0)
**遥感新AI** .  分享遥感与AI技术结合的前沿资讯

深度是啥？近大远小就是深度，它反映了物体到你的距离。热知识：人的两只眼睛形成立体视觉，可以轻松判断远处的山，近处的人。同样地，机器也需要至少两个摄像头去判断物体远近，然而实际情况却是，他们通常只有一个视角，那么这还能判断物体远近吗？

答案当然可以！港大&抖音联合给出解决方案：直接上大模型，单眼感知深度。链接自取：https://huggingface.co/spaces/LiheYoung/Depth-
Anything

请欣赏论文中的效果：

![](https://mmbiz.qpic.cn/mmbiz_png/jicXQgEGWaibdebDZdxFvYPCbzoEXK1YjfhmUIhm40ZVIyfkic1pRDOnKtbrw8PKibWoyDx1xusUN1ypBsUGLN0lhQ/640?wx_fmt=png&from=appmsg)

![](https://mmbiz.qpic.cn/mmbiz_png/jicXQgEGWaibdebDZdxFvYPCbzoEXK1Yjfvuy0TLdUoHBmMSH4ibTvibDIxDiayticXGrkTatjEiawrD25zfI9f9sW4iaQ/640?wx_fmt=png&from=appmsg)

![](https://mmbiz.qpic.cn/mmbiz_png/jicXQgEGWaibdebDZdxFvYPCbzoEXK1YjffxZQzEuoiaU4AcrxqnJVyrQicMNTIiaePpuxp6XLVMwoQiaicEV4dPTwfXw/640?wx_fmt=png&from=appmsg)

上面四个场景展示了室内静物、人群、室外高楼，具有不同的深度信息，而该模型均能够较好地感知这些场景内不同地物的远近程度，说明了其泛化性能较强。注意到，真实的样本获取代价较高，且不易获取，而该模型提供了一种低廉的获取方式，这对于抠图非常有利！

本着实践出真理的原则，本螺丝钉也尝试了一下，下面是用了手机拍照的结果：

![](https://mmbiz.qpic.cn/mmbiz_png/jicXQgEGWaibdebDZdxFvYPCbzoEXK1Yjfb2yda1a81tMribXWiafSx8rVxIonp9z4yicNWCs24ltHakx5rpqJfuIqg/640?wx_fmt=png&from=appmsg)

![](https://mmbiz.qpic.cn/mmbiz_png/jicXQgEGWaibdebDZdxFvYPCbzoEXK1YjfsuicCibDFW0yMdtEbI663cv1AteLkxb9pUFb1O1F8KsIdoRdnwGU0GEA/640?wx_fmt=png&from=appmsg)

本着遥感螺丝钉的称号，上一些遥感影像看看：

![](https://mmbiz.qpic.cn/mmbiz_png/jicXQgEGWaibdebDZdxFvYPCbzoEXK1YjfYwAFEZpGa0HG7AuYxArOndibJo1wAPJH4r0jG55zShUDrwqt4zFxT4Q/640?wx_fmt=png&from=appmsg)  

这效果也有点太逆天了，上图显示，对于一张俯视图（遥感卫星影像），该模型仍然能够有效识别出建筑和地面的远近，说明啥，说明咱们遥感人赶快学（juan) 起来!

预览时标签不可点

微信扫一扫  
关注该公众号





****



****



  收藏


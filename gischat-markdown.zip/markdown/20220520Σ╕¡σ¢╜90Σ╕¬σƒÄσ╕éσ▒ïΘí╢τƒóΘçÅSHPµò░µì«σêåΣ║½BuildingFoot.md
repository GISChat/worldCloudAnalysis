![cover_image](https://mmbiz.qlogo.cn/mmbiz_jpg/S9HsqSVeUqt8zgiaSqYlrkrfiarE9vNBpCO3J9PoibZMNAeO9zV1OGhs1RvywYROKicniaoGBfEfH2BUwFS7H4z5hnQ/0?wx_fmt=jpeg)

#  中国90个城市屋顶矢量SHP数据分享(BuildingFoot)

原创  张喵喵  [ 城市感知计算 ](javascript:void\(0\);)

**城市感知计算**

微信号  sensingcity

功能介绍  认识世界和改造世界，分享地理信息系统科普知识与学术研究，欢迎加好友学术交流。

__ __

__ _ _ _ _

###  今天看到大家都在转发微软发布的全球尺度建筑屋顶数据集,分区下载地址如下,但是美中不足的是,可能由于政策的限制,很多国家特别是国内数据空白。

https://github.com/microsoft/GlobalMLBuildingFootprints

![](https://mmbiz.qpic.cn/mmbiz_png/S9HsqSVeUqt8zgiaSqYlrkrfiarE9vNBpC9Dhg0M6AUdOLvBian2DcDaVwnpqhSgwEO4DTM8OAgYMakfkAM6dpMuw/640?wx_fmt=png)

###
前一段南京师范大学利用遥感影像解译了中国90个主要城市的建筑屋顶矢量数据(https://www.nature.com/articles/s41597-022-01168-x),中山大学也有类似的工作,解译了中国2亿+栋农村房屋建筑,这些工作都有一个特点,就是识别出的数据量极为庞大,但是方法并不是很难。

![](https://mmbiz.qpic.cn/mmbiz_png/S9HsqSVeUqt8zgiaSqYlrkrfiarE9vNBpC8cNzqficibTGokYK7O3JxWPG16F4d3PkAg7RyIRU9WurtfT98Wwjj8jg/640?wx_fmt=png)

（图片来自论文原文  code:https://github.com/ChanceQZ/RoofTopSegmatation  ）

  

![](https://mmbiz.qpic.cn/mmbiz_png/S9HsqSVeUqt8zgiaSqYlrkrfiarE9vNBpCblhEUyCRPydBlQ4zlxo9AkJsP8pkpcZxOwkpuCF5pCjIdYO2NicfJ1A/640?wx_fmt=png)  

（图片来自论文原文）

###  屋顶面积数据集按城市层级排列，每个城市的屋顶面积数据为 ESRI Shapefile 格式，由 .shx、.shp、.prj、.dbf 和
.cpg 文件组成。数据集分为原始版本和简化版本。原始版本由模型的预测结果直接转换，简化版本约为  21.3
G，原始版本约为118Gb。文件数据采用FTP服务方式进行传输，方便大家取阅我把简化版本上传到网盘。我加载了武汉市的矢量数据简单看了一下，质量还是挺不错的，可以做各种灾害风险的较细尺度的评估。虽然存在一些小的异常值，大家使用时可以设置面积筛选，剔除掉这些误差，只保留面积比较大的建筑。

链接：https://pan.baidu.com/s/1_1qH1O7qHQ3ZPDLd0wyVGQ

提取码：ezev。后台回复 建筑矢量 获取更新网盘链接。

![](https://mmbiz.qpic.cn/mmbiz_png/S9HsqSVeUqt8zgiaSqYlrkrfiarE9vNBpChicFfdcicp7NtmXjkZtgNtsTEreiaT78wLUicjA2G9YcPbx582QReHyzJA/640?wx_fmt=png)

![](https://mmbiz.qpic.cn/mmbiz_png/S9HsqSVeUqt8zgiaSqYlrkrfiarE9vNBpCXyjiaIcldmb4zfHtyKQZDL9H9L3QT6FlIdkT4RfbBribT7rTQIe0Puug/640?wx_fmt=png)

预览时标签不可点

微信扫一扫  
关注该公众号





****



****



  收藏


![cover_image](https://mmbiz.qpic.cn/mmbiz_jpg/M98NicsEqGhg9Gib0CiaAVSRb2khtumabjt3GbtowJZEzl7op18XzyYLUYo4Micxx7EmMVEdR98aLfv29vp43HUpwA/0?wx_fmt=jpeg)

#  GISer last软件、制图与数据总结

[ 城市感知计算 ](javascript:void\(0\);)

**城市感知计算**

微信号  sensingcity

功能介绍  认识世界和改造世界，分享地理信息系统科普知识与学术研究，欢迎加好友学术交流。

__ __

__ _ _ _ _

以下文章来源于GISer last  ，作者GISer last

![](http://wx.qlogo.cn/mmhead/Q3auHgzwzM7aM9vfrdQCeCJExBLGqZmFwvuIdZWS1VfPbyef52agKQ/0)
**GISer last** .  GISer last 公众号
主要以分享互联网数据资源为主。也分享过GIS、FME等技术教程方法。我个人对于大数据资源、可视化制作、地图制图等方面有很大兴趣，也会分享个人的一些应用和教程。

距离上次推文分类汇总已经过去了半年左右的时间，今天更新一下公众号推文，方便大家查询  

在过去的两年左右的时间里，作为一名数据搬运工的我，在给大家搬运互联网数据及相关资源的同时，也推送了很多GIS、FME、mapublisher、制图及其他简易教程等等相关的内容。今天更新一下，以方便大家了解一下GISer
last的分享。当然也欢迎关注我的公众号，同时可以吧星球设置星标，推文发送的时候，您第一时间收到我发送的推文。  

![](https://mmbiz.qpic.cn/mmbiz_png/M98NicsEqGhjqWEia7rvwyib0GLVe2bwNefamSicF7dOxCrUC0T2PZpUgLHgNtiaicxxEXqLrkCV6YhWByiaGQWEkmbCA/640?wx_fmt=png)

** 提醒：随意点击下面的文章标签，即可跳转至推文的页面。  **  

  

** 【 ** ArcGis软件  ** 】  
**

最近收到不少的朋友的咨询，关于arcgis软件的操作，这里提供三个小建议：  
1、B站关于arcgis软件的视频非常多，大部分讲解的非常详细。花点时间观看  
2、arcgis书籍的话，南师大汤国安老师、山科大牟乃夏老师等老师的GIS书籍  
3、获取每个人的需求不一样，但如果使用arcgis软件，请多多动手操作，练习

[ 01：ArcGIS的地图模板  
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247486933&idx=2&sn=5a2e1a760f8514ec1a61097750caa352&chksm=97c05ca6a0b7d5b075bd45a663dfa9e6283a36071fba00e2183e8acf9d10dc58cb343d0ff80b&scene=21#wechat_redirect)

[ 02：ArcGIS坐标的三个小知识
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247486954&idx=1&sn=38045686594397e1527723683441afc6&chksm=97c05c99a0b7d58f7625db39f4746df7d202cce759268a6188d37f4b7a44e243e98997e82615&scene=21#wechat_redirect)

[ 03：ArcGIS编辑功能
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247487177&idx=2&sn=7980cc211da08cda598fce2bce7b5aed&chksm=97c05fbaa0b7d6ac69e33df27d5c637eb4f0c28d032ffa4b32b7f311fa2f00b84ae733377b9e&scene=21#wechat_redirect)

[ 04：ArcGIS制图功能
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247487404&idx=1&sn=b650fa4ed4d8627a4a4cf99c248bfbed&chksm=97c05edfa0b7d7c9940cfbaf524c9d43b0a6723df49c6cc5b317f6655c913f7b0a5ccaa103ca&scene=21#wechat_redirect)

[ 05：ArcGIS全图功能
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488112&idx=1&sn=7cc98ad0667a19120cda36b39ff7ada0&chksm=97c04303a0b7ca158314a89576d3234326553569e59501674ddf724c3729d3d84148f83faae7&scene=21#wechat_redirect)  

[ 06：
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488190&idx=1&sn=f66b4f585209717a8cdcce8af14ebf52&chksm=97c043cda0b7cadba50e0a0579189ef9a79ebc229a204ed24511d7af2a0ce1714aa7bdfbcf15&scene=21#wechat_redirect)
[ ArcGis 软件制作双变量等值区域地图(Bivariate Choropleth Maps)
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488190&idx=1&sn=f66b4f585209717a8cdcce8af14ebf52&chksm=97c043cda0b7cadba50e0a0579189ef9a79ebc229a204ed24511d7af2a0ce1714aa7bdfbcf15&scene=21#wechat_redirect)

[
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488190&idx=1&sn=f66b4f585209717a8cdcce8af14ebf52&chksm=97c043cda0b7cadba50e0a0579189ef9a79ebc229a204ed24511d7af2a0ce1714aa7bdfbcf15&scene=21#wechat_redirect)
[ 07：
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488190&idx=1&sn=f66b4f585209717a8cdcce8af14ebf52&chksm=97c043cda0b7cadba50e0a0579189ef9a79ebc229a204ed24511d7af2a0ce1714aa7bdfbcf15&scene=21#wechat_redirect)
[ ArcGIS Pro 2.8软件的GIS练习数据
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488190&idx=1&sn=f66b4f585209717a8cdcce8af14ebf52&chksm=97c043cda0b7cadba50e0a0579189ef9a79ebc229a204ed24511d7af2a0ce1714aa7bdfbcf15&scene=21#wechat_redirect)
‍  

[ 08：ArcGIS软件加载部分省级遥感影像服务
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488777&idx=1&sn=7d12b0cf58cecb45d5a15166d1a270ba&chksm=97c0447aa0b7cd6c06b71a15917d62c852129f84d2fb86bdd79cd1929350102e8ba8301c534b&scene=21#wechat_redirect)  

[ 09：ArcGIS Editor for OSM, 10.0-10.8版本
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247485776&idx=1&sn=db3f569353ff7981be8c8b95ad5d6620&chksm=97c05823a0b7d135f706b3ec402a7732395218881ce7cd6dbc32930d0f7dac03b18b11e7ab14&scene=21#wechat_redirect)

[ 10：
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489290&idx=1&sn=bfdfb383edf4a9b862a642210585005a&chksm=97c04679a0b7cf6f8d35d68cc7b1e62c93a582a674ad414d138373e2c92f1064f325f18b1eb3&scene=21#wechat_redirect)
[ arcgis pro 2.9、pro2.8和arcgis8.1及插件MapChartdesktop等资源。
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489290&idx=1&sn=bfdfb383edf4a9b862a642210585005a&chksm=97c04679a0b7cf6f8d35d68cc7b1e62c93a582a674ad414d138373e2c92f1064f325f18b1eb3&scene=21#wechat_redirect)  

11：  [ ArcGIS 代码共享：代码、脚本、模型、插件、小部件等
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490836&idx=1&sn=ba291dccbd5941fe3f33ef901cea179b&scene=21#wechat_redirect)  

12：  [ 推荐一个优秀的GIS 学习资源网站。
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490085&idx=1&sn=3d2cdb4a51c24f76e3daee14cba538e3&scene=21#wechat_redirect)  

  

** 【QGIS ** 软件  ** 】  **

不知不自觉的也已经给大家分享了10篇QGIS软件方面的内容了。QGIS软件是个开源软件，制作出来的效果非常的不错。我平时用它主要是获取网络上的数据资源，其他它的功能远远不止于此。如果对QGIS软件感兴趣的话，可以去学习一下张云金老师分享的QGIS软件的插件使用。  

  

01：  [ QGIS软件加载星图地球的服务，流畅且清晰度还可以。  
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490404&idx=1&sn=97f90b54edc353c63b207ff81872c6d0&scene=21#wechat_redirect)

[ 02：QGIS软件中多图共用一图例的操作步骤。
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490404&idx=1&sn=97f90b54edc353c63b207ff81872c6d0&scene=21#wechat_redirect)

03：  [ QGIS软件制作一个全球地形的可视化效果图  
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490327&idx=1&sn=ed36ab80a80b44b64ef6d56f8c93ae2d&scene=21#wechat_redirect)

[ 04：QGIS软件中山体阴影浮雕效果的参数设置。
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490327&idx=1&sn=ed36ab80a80b44b64ef6d56f8c93ae2d&scene=21#wechat_redirect)

05：  [ QGIS 软件5个入门的视频小教程
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489937&idx=1&sn=21ef0d390aa01fe2efc63e0859e1550a&scene=21#wechat_redirect)
:  

06：  [ QGIS软件加载 GeoScene Online网站上的数据资源
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489937&idx=1&sn=21ef0d390aa01fe2efc63e0859e1550a&scene=21#wechat_redirect)

07：  [ 分享QGIS软件加载全球夜间灯光数据。
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489185&idx=1&sn=8226417ab836f57ec3158650d5050048&scene=21#wechat_redirect)  

08：  [ 使用 QGIS 和开源数据进行地理空间分析
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489185&idx=1&sn=8226417ab836f57ec3158650d5050048&scene=21#wechat_redirect)

09：  [ 如何巧妙的获取mapbox底图的矢量化数据
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489023&idx=2&sn=11f234b86886f64360835835eec97bcd&scene=21#wechat_redirect)

10：  [ 如何使用 QGIS 或 ArcMap 创建一个GeoPDF
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489023&idx=2&sn=11f234b86886f64360835835eec97bcd&scene=21#wechat_redirect)

  

** 【 ** FME软件  ** 】  
**

FME一点点经验已经发了六篇推文了，大部分都是我自己摸索尝试使用的。  

后面也会继续更新，到时候把我的拿得出手的绝活算是，SHP转CAD分享给大家。  

SHP转CAD，分图层、带填充、有面积要求。这里提醒一句：不要小瞧了FME，非常强大的一款软件。  

  

[ 01：读取ArcGIS的方式
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489353&idx=6&sn=56bc0871d2d6a65bebe43b7c24cfa6b5&chksm=97c0463aa0b7cf2c80d828b9f010b418c8cdecdcc90eeaafc2bd4eccf853cc4a4feb97a7f111&scene=21#wechat_redirect)

[ 02：json格式转shp操作教程
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489353&idx=5&sn=c139d45af911dfc2706bcabe6150dfda&chksm=97c0463aa0b7cf2cb9c85ec3c0dfdd962e5b5cc0d24a556c7d230091d716dc2c89399c5c1d95&scene=21#wechat_redirect)

[ 03：获取菜鸟运输市场线路数据
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489353&idx=4&sn=adf3164024b129f2f34c95da9f17c491&chksm=97c0463aa0b7cf2c718411e641d18a4f80310289ddd4e07babd01a23bc52573c16edb6259021&scene=21#wechat_redirect)

[ 04：批量合并2022年公众版GDB数据
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489353&idx=3&sn=a964fc40cdf169fd7e376bdb0c5490a6&chksm=97c0463aa0b7cf2c81160e3b29f2b6a2ede7beea39658879c5c4c371d41099043f3923188556&scene=21#wechat_redirect)

[ 05：教你怎么下载乡镇街道数据
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489353&idx=2&sn=5978033378a61530315cac7ed9afe35c&chksm=97c0463aa0b7cf2cd980627aaf5ed8caa421a919657c9b30b1920c54b9765f8d73fb687a0fa4&scene=21#wechat_redirect)

06：  [ 教你怎么获取天地图数据
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247491184&idx=1&sn=c6cde192a5c880c0aa69bbc975c84f7e&scene=21#wechat_redirect)  

  

** 【 ** AI & Mapublisher软件  ** 】  **

这几篇是我自己学习的制图过程，至于这块内容如何更新，我还没有想好，但我想呢，抽时间我把这个内容，完整的做一个PDF文件，方便大家学习了解。解决目前标准地图PDF、EPS文件的处理步骤。  

  

[ 01：MAPublisher软件：高质量的地图制图工具
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488710&idx=1&sn=78c9cdd0c3b64bbc024a6ffe3d237daf&chksm=97c045b5a0b7cca39b493f792f6a16fe324e73d78cca7eb3a4aad0a8b7531aefd568c07f5300&scene=21#wechat_redirect)

[
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488494&idx=1&sn=faa03a5c5b3c0827e6bc6e9061f49d39&chksm=97c0429da0b7cb8bf2bb29c913b486fe4493e30b0770f01f21e55672c23df04a5d61cfb08891&scene=21#wechat_redirect)
[ 02：
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488494&idx=1&sn=faa03a5c5b3c0827e6bc6e9061f49d39&chksm=97c0429da0b7cb8bf2bb29c913b486fe4493e30b0770f01f21e55672c23df04a5d61cfb08891&scene=21#wechat_redirect)
[ 地图晕圈的制作步骤
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488494&idx=1&sn=faa03a5c5b3c0827e6bc6e9061f49d39&chksm=97c0429da0b7cb8bf2bb29c913b486fe4493e30b0770f01f21e55672c23df04a5d61cfb08891&scene=21#wechat_redirect)

[
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488506&idx=1&sn=467f9477047d1c23a78f375a9ff5785b&chksm=97c04289a0b7cb9f3e546186da138ef58813f09b91d6f5a675cb8b6d9bae474a014d13dd6087&scene=21#wechat_redirect)
[ 03：
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488494&idx=1&sn=faa03a5c5b3c0827e6bc6e9061f49d39&chksm=97c0429da0b7cb8bf2bb29c913b486fe4493e30b0770f01f21e55672c23df04a5d61cfb08891&scene=21#wechat_redirect)
[ AI软件的四色填色操作过程
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488506&idx=1&sn=467f9477047d1c23a78f375a9ff5785b&chksm=97c04289a0b7cb9f3e546186da138ef58813f09b91d6f5a675cb8b6d9bae474a014d13dd6087&scene=21#wechat_redirect)

[ 04：AI插件添加字段，输入七普数据，可视化操作
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488523&idx=1&sn=39a064c2bb3e4155e77a41f7c9cf2651&chksm=97c04578a0b7cc6ef9d8354e7bd3afca494f9465050e47b0de75c2c8dbc1142821e167ef24e1&scene=21#wechat_redirect)

[ 05：如何对自己制作的三调数据进行快速配色
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488817&idx=1&sn=29f807d898d450014cd2728e10a4f9e6&chksm=97c04442a0b7cd546695c4156d8a01a2e980944111e6f1537cd53c9fcc8c0cb89bf7876c1220&scene=21#wechat_redirect)

[ 06：新方法：道路网多（双）线变单线
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488366&idx=1&sn=9df358130ef0efc9e0268faf7d9f3e98&chksm=97c0421da0b7cb0b444669b0bdd543811684997b98cd53f5d62334471c7eec82f3622b550aa0&scene=21#wechat_redirect)  

[ 07：
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488523&idx=1&sn=39a064c2bb3e4155e77a41f7c9cf2651&chksm=97c04578a0b7cc6ef9d8354e7bd3afca494f9465050e47b0de75c2c8dbc1142821e167ef24e1&scene=21#wechat_redirect)
[ Colorbrewer 2.0网站：配色下载及可视化效果
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488390&idx=1&sn=25696d720af2bb0024d055ea6adfa8c8&chksm=97c042f5a0b7cbe385e7e82610d8750bbcdd004aea1331ec190d262bbf4991e671293a3b72ae&scene=21#wechat_redirect)

08：  [ PDF文件转GIS数据：以安徽省土地利用现状图为例
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489849&idx=1&sn=4145d3edb95075128abe2321e8484852&scene=21#wechat_redirect)  

[ 09：Mapublisher软件的标注功能有两种。
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489979&idx=1&sn=97de01711f692f444eda4537e294ab7e&scene=21#wechat_redirect)

**  
**

** 【 ** Tableau & 可视化  ** 】  **

网上的tableau大神很多，而且制作的可视化图表非常高级，可惜我不会。我只会这些简单点的。这部分大家凑合着看吧。  

  

[ 01: 我是怎么制作土地利用变化的转移矩阵表格的。
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489376&idx=1&sn=bfbda6451e8c8cd8e8c9d0880bc69cc8&chksm=97c04613a0b7cf05254414c99be06f737e680ddb8666153ec1010a52956f13c3f12dd01de48d&scene=21#wechat_redirect)
**  
**

02：  [ 巧方法：38页的PDF表格文件，我是怎么借助Tableau软件处理的。
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489672&idx=1&sn=be1e5a59c410be4b3225cc17b276689a&scene=21#wechat_redirect)  

03：  [ Tableau第三期：深圳市人口热力图数据的简单可视化操作
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489957&idx=1&sn=42acb8a1aab056e49cb58dfed0c2f124&scene=21#wechat_redirect)  

04：  [ 网格法中，求取网格中的最大值及对应的地类名称
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490151&idx=1&sn=a6c958609eaa9563eee1eee0a58794ab&scene=21#wechat_redirect)  

[ 【推荐】go-cart，在线制图生成器  
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490499&idx=1&sn=8271251a06a274ba191a792161b69618&scene=21#wechat_redirect)

[ 分享一个精美的三维地图资源：3D-Mapper Examples
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490271&idx=1&sn=3ad3ed4862f2c076d7c7047056199533&scene=21#wechat_redirect)  

[ 推荐一个数据可视化的案例网站
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490048&idx=1&sn=5f3dc788abe1b01b84ed299309f4aeae&scene=21#wechat_redirect)

[ 分享个有趣的可视化资源网站：城市数据绘图（urbandatapalette）
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489790&idx=1&sn=fb7ea71b86c3e6a217fcf8b405b945c3&scene=21#wechat_redirect)

[ 流程图可视化在线工具：Flowmap（数据源链接也提供了。）
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489751&idx=1&sn=00a1f78a29034e38a89dc38783169f4f&scene=21#wechat_redirect)

  

  

  

** 【 ** 标准地图 & 制图  ** 】  
**

标准地图这块，多数省份的2022年的标准地图都已经更新了，很多省份直接提供了PDF和EPS的矢量文件，这就方便了大家的使用。后续我会继续关注这块内容，而且给大家继续分享标准地图方面的数据、处理以及制图。  

  

[ 01：我把标准地图的EPS文件整理成了28个图层，感兴趣可以去试试。
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488439&idx=1&sn=161c781c07cef2e88725e4f254050428&chksm=97c042c4a0b7cbd287cc4e7b0de5066185207b1c823b464525968918d7f5aed06b88745ee6de&scene=21#wechat_redirect)

[
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488546&idx=1&sn=6f623040eaea3e7a860612906a06e1d5&chksm=97c04551a0b7cc4785c9138db77750f8c132d0de448ed492fc7e383349a322abc556d0b9e02f&scene=21#wechat_redirect)
[ 02：
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488494&idx=1&sn=faa03a5c5b3c0827e6bc6e9061f49d39&chksm=97c0429da0b7cb8bf2bb29c913b486fe4493e30b0770f01f21e55672c23df04a5d61cfb08891&scene=21#wechat_redirect)
[ 标准地图整理成28个图层后，下一步该配准数据了。
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488546&idx=1&sn=6f623040eaea3e7a860612906a06e1d5&chksm=97c04551a0b7cc4785c9138db77750f8c132d0de448ed492fc7e383349a322abc556d0b9e02f&scene=21#wechat_redirect)  

[ 03：
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488494&idx=1&sn=faa03a5c5b3c0827e6bc6e9061f49d39&chksm=97c0429da0b7cb8bf2bb29c913b486fe4493e30b0770f01f21e55672c23df04a5d61cfb08891&scene=21#wechat_redirect)
[ AI插件：标准地图配准后，加载数据及动态投影，以世界地图为例。
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488564&idx=1&sn=b9e2239ecdc84d49d93747b6d2a337b8&chksm=97c04547a0b7cc51a66be71f712c8e752a47a281a68f31ab289835d76ebac48aa0f3fd13bbcd&scene=21#wechat_redirect)

[
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488604&idx=1&sn=975f46f1e77652be582fb2d3b7c56192&chksm=97c0452fa0b7cc39d5e6b697d3fc6f97346354b3f6c14e759c1659869f4d6ff3064ff2e4fceb&scene=21#wechat_redirect)
[ 04：
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488494&idx=1&sn=faa03a5c5b3c0827e6bc6e9061f49d39&chksm=97c0429da0b7cb8bf2bb29c913b486fe4493e30b0770f01f21e55672c23df04a5d61cfb08891&scene=21#wechat_redirect)
[ 尝试制作一幅全球土地利用/土地覆盖现状图
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488604&idx=1&sn=975f46f1e77652be582fb2d3b7c56192&chksm=97c0452fa0b7cc39d5e6b697d3fc6f97346354b3f6c14e759c1659869f4d6ff3064ff2e4fceb&scene=21#wechat_redirect)

[ 05：
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488494&idx=1&sn=faa03a5c5b3c0827e6bc6e9061f49d39&chksm=97c0429da0b7cb8bf2bb29c913b486fe4493e30b0770f01f21e55672c23df04a5d61cfb08891&scene=21#wechat_redirect)
[ 不考虑坐标系，我是如何处理标准地图的EPS文件及七普数据的可视化。
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489279&idx=1&sn=9431891f3276b0bccc3e804216328e9e&chksm=97c0478ca0b7ce9a44b2152efbc3bf904a7e25ff96e01cf12ee293b02317356e0bcde1dd2286&scene=21#wechat_redirect)

06：  [ 西藏公开发布了标准地图的mxd模板和mdb数据库。
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490470&idx=1&sn=636ef3d8cd7143719316611a9aa3a19c&scene=21#wechat_redirect)

07：  [ 山东省标准地图2022版（附链接）
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490171&idx=1&sn=447f428787fa86f1373b894ab59580f0&scene=21#wechat_redirect)  

08：  [ 中国南海的标准地图，留言咨询的朋友可以去下载保存了。
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490295&idx=1&sn=d783650e35c16ae395436bc481e702eb&scene=21#wechat_redirect)  

  

  

** 【简单教程】  
**

**  
**

** [ 我是如何获取县区级第七次人口普查数据的，留言的朋友们来看看过程多简单吧。
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247491480&idx=2&sn=084108301efdccf378861ff132949f13&scene=21#wechat_redirect)  
**

** [ 推荐一个的网站：curlconverter网站，我用高德地图做了测试。
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490899&idx=1&sn=89c4e506a21fde15312aefce597c71b5&scene=21#wechat_redirect)  
  
**

[ ](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247485822&idx=1&sn=46e35227316140202d16a6eff8d6902e&chksm=97c0580da0b7d11b3b388177ce158d3262b758d6c9fc2237fed58aa3bfcdab60bda25ab8aa54&scene=21#wechat_redirect) [ 01：  ](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488439&idx=1&sn=161c781c07cef2e88725e4f254050428&chksm=97c042c4a0b7cbd287cc4e7b0de5066185207b1c823b464525968918d7f5aed06b88745ee6de&scene=21#wechat_redirect) [ 和弦图 | 傻瓜式制作流程（以省际间煤炭流动数据为例）  ](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247485822&idx=1&sn=46e35227316140202d16a6eff8d6902e&chksm=97c0580da0b7d11b3b388177ce158d3262b758d6c9fc2237fed58aa3bfcdab60bda25ab8aa54&scene=21#wechat_redirect)

[ ](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247485965&idx=1&sn=e9ea800d05c0e58214f4478d590e0dbb&chksm=97c05b7ea0b7d26820c561176974fba5062e660db5d231cb955331c469fcb95589044c512b5a&scene=21#wechat_redirect) [ 02：  ](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488439&idx=1&sn=161c781c07cef2e88725e4f254050428&chksm=97c042c4a0b7cbd287cc4e7b0de5066185207b1c823b464525968918d7f5aed06b88745ee6de&scene=21#wechat_redirect) [ 和弦图 | 交互式制作教程（以菜鸟运输线路数据为例）  ](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247485965&idx=1&sn=e9ea800d05c0e58214f4478d590e0dbb&chksm=97c05b7ea0b7d26820c561176974fba5062e660db5d231cb955331c469fcb95589044c512b5a&scene=21#wechat_redirect)

[ 03：教程分享 | 如何获取港口网（全球船舶点和路径）的数据  ](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247486202&idx=1&sn=b0aefcf2f004a50c3f6815f93e4a3e91&chksm=97c05b89a0b7d29fdeb80bc429a71a2c1fd61184e054ea180b8608fcbd77bd7631f952468f8a&scene=21#wechat_redirect)

[ 04：
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488439&idx=1&sn=161c781c07cef2e88725e4f254050428&chksm=97c042c4a0b7cbd287cc4e7b0de5066185207b1c823b464525968918d7f5aed06b88745ee6de&scene=21#wechat_redirect)
[ 【词云图制作】分享一期热搜评论的词云图制作
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488061&idx=1&sn=0e6a0a411db88f0c102f87dcc72a21f8&chksm=97c0434ea0b7ca5879898e485ce7815592f15de060abbcc9533721b04adf0e47be2bc5768cad&scene=21#wechat_redirect)

#  [ 05：我是如何获取县区级第七次人口普查数据的，留言的朋友们来看看过程多简单吧。
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489248&idx=1&sn=187e3f54175d20e1764d418e1d7c6b26&chksm=97c04793a0b7ce85b68b7f3c00478d9185418da4faecd25e164ee2f8dbf83ee29a15af68b652&scene=21#wechat_redirect)

#  [ 06：如何巧妙的获取mapbox底图的矢量化数据
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489089&idx=2&sn=5c0fa9e9e8332f2b12ab48c2c39d178d&chksm=97c04732a0b7ce2486e00e8d2b1e38ef6cd11f4c03f565a80f43bbc10fbcdaafffba79e5452a&scene=21#wechat_redirect)

#  07：  [ 巧方法：天地图遥感影像的下载教程，不来试试嘛。
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489593&idx=1&sn=1c1e42ee130a205da2e0b37218af6c6c&scene=21#wechat_redirect)

** 还有两个等时圈的教程：  **

[ 教程分享 | Mapbox网站获取等时圈数据  ](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247486229&idx=2&sn=ddd37ece9975c64415891dd613a4b99a&chksm=97c05a66a0b7d37041f74991a2b21f0ab4c20de5b33fd5e6b0d326fcf512391c654d71846846&scene=21#wechat_redirect)

[ 教程分享 | 教你如何获取网络上的等时圈数据（范围、面积、可达性指标、人口等）  ](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247486199&idx=1&sn=1dc47058c34ea0ff14acd8ab8a12d4c1&chksm=97c05b84a0b7d292bac8303452f070fe88a23b5166201447cada4fbb940b86d4ec67a8a9c469&scene=21#wechat_redirect)   

  

** 【数据资源】  **

** 一、人口数据  
**

人口数据已经分享的足够多了，后面专注分享乡镇街道的七普人口及gis数据。  

  

[ ** 2020年中国人口普查分县资料（PDF版本）  **
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247491480&idx=1&sn=b5a7c7525316cfeadfc2b92f6f8ac8e4&scene=21#wechat_redirect)  

[ ** 全国分省汇总的县级七普人口数据在哪下载？？  **
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247491480&idx=3&sn=3337f181ecc5a8351a55c6700d023e07&scene=21#wechat_redirect)  

[ ** 密歇根大学中国数据中心：中国历史县人口普查数据（1953 年、1964 年、1982 年、1990 年、2000 年）  **
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490867&idx=1&sn=886be5c91d058a38861e15d4747e862f&scene=21#wechat_redirect)  

[ ** 【分享】全球国家或地区的人口GIS矢量数据（总数、性别、年龄段、占比等属性）2000-2020年  **
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490620&idx=1&sn=b096a43646fbea9481f0b84e7c678154&scene=21#wechat_redirect)  

[ ** 再来一份：1953–2010年人口普查数据（Excel 和 GIS文件）  **
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247491480&idx=4&sn=e8563fe2b2817bad05f948f63beb2c6c&scene=21#wechat_redirect)  

[ ** 新疆县级七普、六普人口GIS数据  **
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247491391&idx=1&sn=d39d595754b567c569b9390d80fdbc90&scene=21#wechat_redirect)  

[ ** 2018年县级区划SHP、腾讯定位数据、全国人口栅格等数据资源  **
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247491250&idx=1&sn=02b50478a42d63a8d00797b2da67bae6&scene=21#wechat_redirect)  

[ ** 北京市乡镇人口普查数据变量列表属性（2000年）  **
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490823&idx=1&sn=96e8a803e527dcfd580b54065df6b1d5&scene=21#wechat_redirect)  

[ ** 搜集乡镇街道的七普人口，这里有几种方法。  **
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489731&idx=1&sn=39ffd15232024c3da07d12a63700a015&scene=21#wechat_redirect)

[
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489394&idx=1&sn=107206ca22d1d0b55908a683c0b6a4c4&chksm=97c04601a0b7cf1757048766fa2acffc67065f614e47ee3ad1d96a28341ce97c7f6b28e00651&scene=21#wechat_redirect)
[ 01：
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489248&idx=2&sn=ac359bc498d0f59276a7af4559c788ea&chksm=97c04793a0b7ce856cd54e097d48b865c01f1000af646d1045fb2cf13fc43e42b5ffe4862033&scene=21#wechat_redirect)
[ 全球2000-2020年LandScan数据集，不受限制地向公众提供了。
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489394&idx=1&sn=107206ca22d1d0b55908a683c0b6a4c4&chksm=97c04601a0b7cf1757048766fa2acffc67065f614e47ee3ad1d96a28341ce97c7f6b28e00651&scene=21#wechat_redirect)  

[
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489248&idx=2&sn=ac359bc498d0f59276a7af4559c788ea&chksm=97c04793a0b7ce856cd54e097d48b865c01f1000af646d1045fb2cf13fc43e42b5ffe4862033&scene=21#wechat_redirect)
[ 02：
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489248&idx=2&sn=ac359bc498d0f59276a7af4559c788ea&chksm=97c04793a0b7ce856cd54e097d48b865c01f1000af646d1045fb2cf13fc43e42b5ffe4862033&scene=21#wechat_redirect)
[ 全国分省汇总的县级七普人口数据在哪下载？？
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489248&idx=2&sn=ac359bc498d0f59276a7af4559c788ea&chksm=97c04793a0b7ce856cd54e097d48b865c01f1000af646d1045fb2cf13fc43e42b5ffe4862033&scene=21#wechat_redirect)

[
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489325&idx=2&sn=2a09848c2518a7301858760fafc2ec18&chksm=97c0465ea0b7cf4829c57b87e970485d7371f47ea175534f2d0518b1ab442d96f2808180e78d&scene=21#wechat_redirect)
[ 03：
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489248&idx=2&sn=ac359bc498d0f59276a7af4559c788ea&chksm=97c04793a0b7ce856cd54e097d48b865c01f1000af646d1045fb2cf13fc43e42b5ffe4862033&scene=21#wechat_redirect)
[ 2000年、2010年全国乡镇街道人口栅格数据集
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489325&idx=2&sn=2a09848c2518a7301858760fafc2ec18&chksm=97c0465ea0b7cf4829c57b87e970485d7371f47ea175534f2d0518b1ab442d96f2808180e78d&scene=21#wechat_redirect)

[
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489325&idx=1&sn=3dd8fa59d71a3468768f60405df753fa&chksm=97c0465ea0b7cf483b7edb9c42de256b7960d54dc7802a8c842e868f651526f6fcb62f511009&scene=21#wechat_redirect)
[ 04：
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489248&idx=2&sn=ac359bc498d0f59276a7af4559c788ea&chksm=97c04793a0b7ce856cd54e097d48b865c01f1000af646d1045fb2cf13fc43e42b5ffe4862033&scene=21#wechat_redirect)
[ 2010年全国乡镇街道人口普查的GIS面数据。
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489325&idx=1&sn=3dd8fa59d71a3468768f60405df753fa&chksm=97c0465ea0b7cf483b7edb9c42de256b7960d54dc7802a8c842e868f651526f6fcb62f511009&scene=21#wechat_redirect)

[
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488857&idx=2&sn=7d959391dfbb689540aa360c60e36ab7&chksm=97c0442aa0b7cd3cc447dd7c8b0460e454e8452f6a1dc0cfc1f654069b2886092005e70ef0d2&scene=21#wechat_redirect)
[ 05：
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489248&idx=2&sn=ac359bc498d0f59276a7af4559c788ea&chksm=97c04793a0b7ce856cd54e097d48b865c01f1000af646d1045fb2cf13fc43e42b5ffe4862033&scene=21#wechat_redirect)
[ 1953–2010年人口普查数据（Excel 和 GIS文件）
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489248&idx=3&sn=197e7133a90b68d96218a1b6ed93f981&chksm=97c04793a0b7ce8598c86123fdb1908a0da4ebf7c9436c9dc28c6e90e3c4eb56320e2cb741ff&scene=21#wechat_redirect)

[ 06：
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489248&idx=2&sn=ac359bc498d0f59276a7af4559c788ea&chksm=97c04793a0b7ce856cd54e097d48b865c01f1000af646d1045fb2cf13fc43e42b5ffe4862033&scene=21#wechat_redirect)
[ WorldPop2000-2020年全球人口年龄-性别结构矢量数据
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247487826&idx=2&sn=b2109954ab65b39036ca117d85b832aa&chksm=97c04021a0b7c937fa9ed1aef46143479e59bda02380b0ffd3c7d5dd68686da023f5b72aad66&scene=21#wechat_redirect)

[ 07：
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489248&idx=2&sn=ac359bc498d0f59276a7af4559c788ea&chksm=97c04793a0b7ce856cd54e097d48b865c01f1000af646d1045fb2cf13fc43e42b5ffe4862033&scene=21#wechat_redirect)
[ 中国流动人口卫生计生动态监测健康数据（2009-2017年）
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247487347&idx=2&sn=63c5368c6442d4d3bcd429224035bb21&chksm=97c05e00a0b7d716180601f03003acd3e16f99aa8e585c38c9e2d65d50c6b7cde81079e94cfb&scene=21#wechat_redirect)

[ 08：
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489248&idx=2&sn=ac359bc498d0f59276a7af4559c788ea&chksm=97c04793a0b7ce856cd54e097d48b865c01f1000af646d1045fb2cf13fc43e42b5ffe4862033&scene=21#wechat_redirect)
[ 宁波市北仑区人口流动大数据分析（各省市人口流向北仑区数据汇总）
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247485821&idx=1&sn=da021e368cf95e1225415bd68c9d5abf&chksm=97c0580ea0b7d118d67f3fbd6b6651a003621e241769c9b70891995c2acb367286309a76999a&scene=21#wechat_redirect)

[ 09：
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489248&idx=2&sn=ac359bc498d0f59276a7af4559c788ea&chksm=97c04793a0b7ce856cd54e097d48b865c01f1000af646d1045fb2cf13fc43e42b5ffe4862033&scene=21#wechat_redirect)
[ 哈佛大学世界地图8300多个地图服务（以中国六次人口普查为例）
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247485470&idx=1&sn=bb4c8ce6f50d8ce5c718f241d41b7901&chksm=97c0596da0b7d07bb9ecf5316183dc0dc61c3f6f883d78102c8fedb817734913d8cb404db827&scene=21#wechat_redirect)

[ 10：
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489248&idx=2&sn=ac359bc498d0f59276a7af4559c788ea&chksm=97c04793a0b7ce856cd54e097d48b865c01f1000af646d1045fb2cf13fc43e42b5ffe4862033&scene=21#wechat_redirect)
[ 湖南省人口流动大数据展示平台
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247485372&idx=1&sn=a10b25189bba41844c7fb69ec07fdb28&chksm=97c056cfa0b7dfd98c91577e0156dc66c6c8747305e58bbcbb7ae4899ce21d93991aff1396b6&scene=21#wechat_redirect)  

  

** 二、土地利用数据  **

这部分数据数据资源我去年发过很多，后来因为某些原因我把数据资源删掉了。如果链接失效了等我后面重新发吧。

[
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488738&idx=1&sn=81a081e3efbe0a4173e7765ad4190006&chksm=97c04591a0b7cc87925751aa8a39e114e0342dd8625221c39d3e092c6845c6c394906eb32a59&scene=21#wechat_redirect)
[ 1km分辨率
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247487382&idx=1&sn=60e01206b73a317c1748a2410cc2b3d2&chksm=97c05ee5a0b7d7f335bb319b136ed5248aecac8b22d3a1cc40cafa406882cae833c136ffadf4&scene=21#wechat_redirect)
：  [ 全球土地覆盖图：GlobCover 2009和Globcover 2005
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488738&idx=1&sn=81a081e3efbe0a4173e7765ad4190006&chksm=97c04591a0b7cc87925751aa8a39e114e0342dd8625221c39d3e092c6845c6c394906eb32a59&scene=21#wechat_redirect)

[ 10m分辨率土地利用分类数据集
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488177&idx=1&sn=b33fbfa550d6e989ec8932b5a9ba6303&chksm=97c043c2a0b7cad4a82c8dd53329be0833b5ec9224567e8dd6f4b28b34c72098786e6dfed4de&scene=21#wechat_redirect)

[ 2m分辨率土地利用分类数据集
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488158&idx=1&sn=986e449d25d13119d38050497c0a3c71&chksm=97c043eda0b7cafbc1dea326df6ee463500ea5610882342e891ee6c2f9b78b25b73a983c6f59&scene=21#wechat_redirect)

[ ](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247486028&idx=1&sn=42624f4ff9032c356439ddde307a3000&chksm=97c05b3fa0b7d229c9e0b13715e5fc359be057f4be04b09ee532fb4a215695c5be1d0d3ff293&scene=21#wechat_redirect) [ 30米  ](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247486028&idx=1&sn=42624f4ff9032c356439ddde307a3000&chksm=97c05b3fa0b7d229c9e0b13715e5fc359be057f4be04b09ee532fb4a215695c5be1d0d3ff293&scene=21#wechat_redirect) [ 分辨率  ](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488158&idx=1&sn=986e449d25d13119d38050497c0a3c71&chksm=97c043eda0b7cafbc1dea326df6ee463500ea5610882342e891ee6c2f9b78b25b73a983c6f59&scene=21#wechat_redirect) |  [ 1985-2020年全球地表覆盖精细分类产品V1.0  ](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247486028&idx=1&sn=42624f4ff9032c356439ddde307a3000&chksm=97c05b3fa0b7d229c9e0b13715e5fc359be057f4be04b09ee532fb4a215695c5be1d0d3ff293&scene=21#wechat_redirect)

[
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247485857&idx=1&sn=050a799942fee70478fbd93be7765adc&chksm=97c058d2a0b7d1c406c017af9a623034230cadc509a17e90c4d5a8b6e68a3be1efe40f94fac6&scene=21#wechat_redirect)
[ 30m
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247485857&idx=1&sn=050a799942fee70478fbd93be7765adc&chksm=97c058d2a0b7d1c406c017af9a623034230cadc509a17e90c4d5a8b6e68a3be1efe40f94fac6&scene=21#wechat_redirect)
[ 分辨率
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488158&idx=1&sn=986e449d25d13119d38050497c0a3c71&chksm=97c043eda0b7cafbc1dea326df6ee463500ea5610882342e891ee6c2f9b78b25b73a983c6f59&scene=21#wechat_redirect)
[ 1985年、1990-2019年中国土地覆盖数据集
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247485857&idx=1&sn=050a799942fee70478fbd93be7765adc&chksm=97c058d2a0b7d1c406c017af9a623034230cadc509a17e90c4d5a8b6e68a3be1efe40f94fac6&scene=21#wechat_redirect)  

[
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247485100&idx=3&sn=33369dc1b96ebac66cf1cdd5e285b063&chksm=97c057dfa0b7dec922bd8e3c88c2ddf705518ef7a826fdc340683eb4dd5fcb6b3010a1a05357&scene=21#wechat_redirect)
[ 100米
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247485100&idx=3&sn=33369dc1b96ebac66cf1cdd5e285b063&chksm=97c057dfa0b7dec922bd8e3c88c2ddf705518ef7a826fdc340683eb4dd5fcb6b3010a1a05357&scene=21#wechat_redirect)
[ 分辨率
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488158&idx=1&sn=986e449d25d13119d38050497c0a3c71&chksm=97c043eda0b7cafbc1dea326df6ee463500ea5610882342e891ee6c2f9b78b25b73a983c6f59&scene=21#wechat_redirect)
[ 全球土地利用2015-2019年数据（精度）
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247485100&idx=3&sn=33369dc1b96ebac66cf1cdd5e285b063&chksm=97c057dfa0b7dec922bd8e3c88c2ddf705518ef7a826fdc340683eb4dd5fcb6b3010a1a05357&scene=21#wechat_redirect)

[
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247485649&idx=1&sn=8714e134493b488565528e786672a8b0&chksm=97c059a2a0b7d0b4245b60a8b216f1aef72030d33dff7c66d22b1e624e63c4811e8e360abee4&scene=21#wechat_redirect)
[ 300米
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247485649&idx=1&sn=8714e134493b488565528e786672a8b0&chksm=97c059a2a0b7d0b4245b60a8b216f1aef72030d33dff7c66d22b1e624e63c4811e8e360abee4&scene=21#wechat_redirect)
[ 分辨率
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488158&idx=1&sn=986e449d25d13119d38050497c0a3c71&chksm=97c043eda0b7cafbc1dea326df6ee463500ea5610882342e891ee6c2f9b78b25b73a983c6f59&scene=21#wechat_redirect)
[ 全球欧空局陆地覆盖（1992—2020年）数据下载
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247485649&idx=1&sn=8714e134493b488565528e786672a8b0&chksm=97c059a2a0b7d0b4245b60a8b216f1aef72030d33dff7c66d22b1e624e63c4811e8e360abee4&scene=21#wechat_redirect)

[
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247487382&idx=1&sn=60e01206b73a317c1748a2410cc2b3d2&chksm=97c05ee5a0b7d7f335bb319b136ed5248aecac8b22d3a1cc40cafa406882cae833c136ffadf4&scene=21#wechat_redirect)
[ 1km分辨率
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247487382&idx=1&sn=60e01206b73a317c1748a2410cc2b3d2&chksm=97c05ee5a0b7d7f335bb319b136ed5248aecac8b22d3a1cc40cafa406882cae833c136ffadf4&scene=21#wechat_redirect)
：  [ 1980-2018年全国土地利用遥感监测图：西安地质调查中心
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247487382&idx=1&sn=60e01206b73a317c1748a2410cc2b3d2&chksm=97c05ee5a0b7d7f335bb319b136ed5248aecac8b22d3a1cc40cafa406882cae833c136ffadf4&scene=21#wechat_redirect)

[ 数据分享：全国和省级年度土地利用现状数据
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247483833&idx=1&sn=531d551735844b0d104d564138bfda58&chksm=97c050caa0b7d9dc48a23b648e341ad0f694648b730dd0371b6bd094e66f8ffdde7432904652&scene=21#wechat_redirect)  

  

** 三、POI数据：  **

[ 188万个POIs：超市、公园、火车站、小学、医院、银行等六类数据
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488945&idx=2&sn=55f424806d5c317a5b2e0f82ca69db69&chksm=97c044c2a0b7cdd48e74ebbf76ebdd9e3179d082b6ddfc391eb9dfabeaf06b12cd2cd697ce34&scene=21#wechat_redirect)

[ 数据分享 | 2021年全国银行业金融机构法人名单及全国银行POI数据  ](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247486380&idx=1&sn=ff2282614be1b7173e02b284d8551e9c&chksm=97c05adfa0b7d3c9f70aca271269033dda16f8185e7e751b7e271adf04fa1c38a1de99208393&scene=21#wechat_redirect)

[ 数据获取教程：如何获取浙江省天地图POI数据
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247485324&idx=1&sn=39559d32aaa90d329ab6757c7e273a8d&chksm=97c056ffa0b7dfe954ab0991f215663aea3e13ea9f01f138d700379b478cbc9ecc4f03f37db7&scene=21#wechat_redirect)

[ 搜集全国POI历史数据的几种途径
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247485252&idx=1&sn=7a2cdfcd585910a59702bf738b7df3dc&chksm=97c05637a0b7df21bc912925e32ea81efae1c22ca008219c047d443f6032f7076a20e0bdc22a&scene=21#wechat_redirect)

[ 数据分享：菜鸟驿站POI数据（9个城市）
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247484372&idx=1&sn=5572a01d183fd61442b19d367f68d49f&chksm=97c052a7a0b7dbb18b24c0c6ad1d9ba5a66f4efeb38df173b9152fa7707429b69dac6b7e9bf2&scene=21#wechat_redirect)

  

** 四、行政区划  
**

关于行政区划数据，很多号主都分享了。目前网上流传的区划数据资源主要：  

1949-2022年全国县级行政区划  

全国乡镇街道的区划数据（全国的、北京市 、上海市、 山东省 、江苏省、 浙江省、江苏省、 江西省 、四川省 、湖南省、 海南省、 广东省、 福建省、
陕西省、 河南省、 云南省 、贵州省 、吉林省 、辽宁省、 黑龙江省等等）  

全国村界区划数据（山东省 、河南省、 湖南省 、云南省 、湖北省、河北省、上海市、重庆市等） **。  
**

**  
**

** [ 全国行政区划GIS数据：审图号为GS（2022）1873号
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247491495&idx=1&sn=a8718918d351d16e0dbe435f0bf36f5c&scene=21#wechat_redirect)  
**

[ 全国2010年以来县级行政区划数据梳理汇总（第一版）
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247487071&idx=1&sn=d35324aabacae6cc6494507a247ee08f&chksm=97c05f2ca0b7d63a0956052d35e6172c782fb4f9970555c52a1b18f92504ca2fac0a9d875ccd&scene=21#wechat_redirect)

[ 2005年全国基础地理数据
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247488857&idx=1&sn=3f0d3ea304d311fb146b31cfcae6039d&chksm=97c0442aa0b7cd3c78e254384bee9b7f119e223ff9cac4408d6ee5dfb245f88343a66c5995b5&scene=21#wechat_redirect)

[ 民政部主办的全国行政区划信息查询平台近期恢复开放查询了。
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247486893&idx=1&sn=629069127aba5a7b4f5dee68671ab4d5&chksm=97c05cdea0b7d5c8bd1384d46c3a1012c8109de6ae4f168719e51df9f0318ebdbb9dc2c62824&scene=21#wechat_redirect)

[ 全国空气质量实时发布平台（包括全国2016年行政区划）
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247485100&idx=2&sn=1469298989f41ff8fd2b39fb5ba4eb0b&chksm=97c057dfa0b7dec9791d51642a94922cffbb710f30e5ea7d9c662eee3be68fd515c4d05ccecf&scene=21#wechat_redirect)

[ 中国 国家地名信息库（2018年全国行政区划数据）
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247485100&idx=1&sn=79dc7a116a27bf55ffca1d8bf599f944&chksm=97c057dfa0b7dec937fc6fdd7e630ca0922e78ef6fca854c910b2be064dd906456427fd9ff95&scene=21#wechat_redirect)

[ 天云南省乡镇、村界数据
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247484898&idx=1&sn=3ebef0525d320730bae816d9f176b794&chksm=97c05491a0b7dd87be89e287d07af21f031d84ad9acff14492a30789f39b5fdfb496c8a1f918&scene=21#wechat_redirect)

[ 福建省乡镇及其他数据分享
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247484490&idx=1&sn=dcdf37455810014b2fe9b3777b1d3e2e&chksm=97c05539a0b7dc2fb57238ae2d406cd2dd0a6f80621c41af080f10c533016b685e80b00c8c20&scene=21#wechat_redirect)

[ 河南省乡镇行政区
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247484381&idx=1&sn=71258be5ad8a9aad56478ed24a3a7525&chksm=97c052aea0b7dbb8028d92ceb2e9e6ba558bb2ab2c755fe8343f8a6649f34b1bcf2deb9826e3&scene=21#wechat_redirect)

[ 江西省乡镇乡镇行政区
](http://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247484135&idx=1&sn=be72e1c3958807a48d709f04ccb922ab&chksm=97c05394a0b7da826d52e6005559587dc6a720c9c3cf86af06af56dd78f5ec9b11c43df5aef7&scene=21#wechat_redirect)  

[ 江西省天地图数据资源已全面更新，包括新版乡镇街道数据。
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489920&idx=1&sn=40a7f7910113d9eb6a5199c4590f90e0&scene=21#wechat_redirect)  

  

** 五、其他数据  **

[ 汇总整理目前全球的道路数据资源
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247491482&idx=1&sn=714d6ae0fe486a785ce91c6a8de41081&scene=21#wechat_redirect)  

[ 推荐10个智慧城市时空大数据云平台
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247491451&idx=1&sn=9cca312fad40b539ed827b368d9354f0&scene=21#wechat_redirect)

[ 线路列表-实时公交数据库
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247491424&idx=1&sn=5bb0864666d33298e99675db17dce4f3&scene=21#wechat_redirect)

[ 省级三线一单数据管理及应用平台
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247491409&idx=1&sn=36f977956f826bc1a6c793369242c723&scene=21#wechat_redirect)

[ 江苏省环境数据公众服务平台
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247491379&idx=1&sn=3b656bc3940bd641ec523b67c709926c&scene=21#wechat_redirect)  

[ 地籍图公开查询系统
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247491364&idx=1&sn=bf1aaf04a4124216246eecff69345915&scene=21#wechat_redirect)

[ 全国分县数据：Annual VIIRS Nighttime Lights v2
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247491345&idx=1&sn=9ab84ce538445deb0763983ee0316375&scene=21#wechat_redirect)

[ 全粤村情数据平台
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247491335&idx=1&sn=ec5983b83d1fd0dbc7c36988c0cfcfbf&scene=21#wechat_redirect)

[ 全国分省重点排污单位监测数据
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247491303&idx=1&sn=0b2fe39078b4d18130e5f1287ed169b2&scene=21#wechat_redirect)

[ 食品安全抽检公布结果查询系统的数据集
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247491279&idx=1&sn=3b7eac80df76828a61bdcb986713a025&scene=21#wechat_redirect)

[ ChinaHighPM 2.5数据集 ：中国高分辨率、高质量的PM 2.5 数据（µg m -3）
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247491267&idx=1&sn=3b58e590ebf6fd63ddc1de83e4995f8d&scene=21#wechat_redirect)

[ 很棒的社区数据集：awesome-gee-community-datasets
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247491235&idx=1&sn=bbe51594d976064244f72b6b54974396&scene=21#wechat_redirect)

[ 瑞铁物流地图：28个图层要素
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247491214&idx=1&sn=b5ba7f0150970d40fa21b644d5dc91de&scene=21#wechat_redirect)

[ 地表水水质监测系统公开数据集
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247491205&idx=1&sn=b02ffc77d7731113a1cdbd34e2baae5c&scene=21#wechat_redirect)

[ 全国电动汽车充电桩分布图
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247491158&idx=1&sn=822e191746d436d757de1408a0093209&scene=21#wechat_redirect)

[ 北京治安地图（包含8种案件类别）
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247491148&idx=1&sn=d19bdc09e813d641e3a30fcdce5ea2ae&scene=21#wechat_redirect)

[ 世界地质公园网络及地质公园信息
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247491132&idx=1&sn=77411c58a3242a1924c926ef6254ee1d&scene=21#wechat_redirect)

[ 安徽省养老机构数字地图及养老机构GIS数据
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247491118&idx=1&sn=daa0bca2a5cc953d4fb539ef13989774&scene=21#wechat_redirect)

[ 全国高速列车时刻表（2016年）以及铁路站点名称和线路名称
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247491108&idx=1&sn=2199a6a3924051b8111d3d51993ef733&scene=21#wechat_redirect)

[ 三调和二调数据，来源国土调查成果共享应用服务平台
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247491084&idx=1&sn=f5412de4370abfe244318580f1d9fe9a&scene=21#wechat_redirect)

[ 海洋图书馆：深入了解海洋数据
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490965&idx=1&sn=9a8ee44b4b6d6e45fa0b5b76e272b74d&scene=21#wechat_redirect)

[ 全球国家或地区之间的资源贸易流量数据（2000-2020年）
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490919&idx=1&sn=86365a0a3a7cd52e128c77fc1f858b52&scene=21#wechat_redirect)

[ 推荐一个网站：我的地理数据云
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490881&idx=1&sn=111f5651a6f0d1ce9f4d71027dbcd504&scene=21#wechat_redirect)

[ 杭州文化和旅游数据在线：文旅数据库、主题数据库和大数据报告等
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490854&idx=1&sn=85123605db6fb80194a04b7aebda7a90&scene=21#wechat_redirect)

[ GBIF：收集生物多样性数据的领先者
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490812&idx=1&sn=7c30614576b78dcad75b20d2c1c757e4&scene=21#wechat_redirect)

[ 【分享】25 个 EBV 数据集，看看有没有感兴趣的。
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490804&idx=1&sn=582fb72c8dd7ed7d7083f4a637c75389&scene=21#wechat_redirect)

[ 【分享】全球化和世界城市研究网络的28个数据集（World City Relational Data）
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490803&idx=1&sn=cdcc72a61d70f593bbce731a7dda80c7&scene=21#wechat_redirect)

[ 【分享】中国高铁数据资源（2011、2016、2019年）
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490783&idx=1&sn=adca7f3d62c7a2379f5f6087fff72750&scene=21#wechat_redirect)

[ 城市水蓝图（urban waterblueprint）
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490746&idx=1&sn=a17d8236e9f40b78943b92461314fb3f&scene=21#wechat_redirect)

[ 【分享】2021年菜鸟运输市场货运线路数据
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490722&idx=1&sn=909cbc8039c3b0b3aa13d3919cba7769&scene=21#wechat_redirect)

[ 【分享】中国海洋保护区在线地图及数据资源
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490702&idx=1&sn=f9e8d26ee5cca0576f1032523e1f24fa&scene=21#wechat_redirect)

[ 【分享】大自然保护协会的地理空间保护图集（数据可以直接下载）
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490688&idx=1&sn=6e1c89e898ec93e4e16d06594959f73b&scene=21#wechat_redirect)

[ 【分享】全球交通、能源和通信基础设施数据资源
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490666&idx=1&sn=84768658f9acb5bc3bac16be7483a0b9&scene=21#wechat_redirect)

[ Sightsmap：全球拍照最多的景点热图
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490665&idx=1&sn=0544eed1484411f996b7fd74266208d5&scene=21#wechat_redirect)  

[ 【分享】全球交通流量GIS数据资源2010-2020年
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490606&idx=1&sn=c69ecceb225bf1f199b68ef66ca16a12&scene=21#wechat_redirect)

[ 推荐：地理学等相关期刊在线检索，惊喜在最后。
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490589&idx=1&sn=2aa8022f50f8519fe719c9008858190a&scene=21#wechat_redirect)

[ 全国33个城市的手机数据集产品
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490552&idx=1&sn=633d39454c2351a66fb6e074bbcba4e7&scene=21#wechat_redirect)

[ 【分享】联合国国家或地区间的移民数据：1990-2020年
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490531&idx=1&sn=0e26efb1791ce36487dc81711fd894b2&scene=21#wechat_redirect)

[ 【分享】高速铁路网络数据集：727个车站、3399列列车和2751713条运行数据
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490516&idx=1&sn=27356b23841edd300023b0266284bc74&scene=21#wechat_redirect)

[ 全球地理名称服务器 (GNS) 数据更新（附服务地址和下载链接）
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490377&idx=1&sn=04b4979e2080978134bc7c8eb7869044&scene=21#wechat_redirect)  

[ 分享一个资源：开放数据影响地图(Open Data Impact Map)
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490231&idx=1&sn=1c5de1473877957393a3db282ff9b4fc&scene=21#wechat_redirect)

[ 搬运：基于中国高速铁路数据的流动性指数
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490215&idx=1&sn=af5da5afbbf91397b0556f54996f3325&scene=21#wechat_redirect)

[ 【推荐】测绘与地理空间技术资源：GISLOUNGE。
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490199&idx=1&sn=29e5544b5bcab48a32370c662e94b7a0&scene=21#wechat_redirect)

[ 2022全球人类住区层GHSL 数据包已经发布。（附数据下载链接。）
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490136&idx=1&sn=9bccb0f3eb900cc1a92fe2a876b86e65&scene=21#wechat_redirect)

[ 15大类地理信息系统专题数据资源。
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490093&idx=1&sn=76d7f89f56bc3c9f265e1d5a18378bbe&scene=21#wechat_redirect)

[ “启明星一号”卫星数据免费向社会开放供科研使用
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247490009&idx=1&sn=4a056e308e39bab414c754a5dfb24b5f&scene=21#wechat_redirect)

[ QGIS、ArcGIS、Leaflet、MapBox等瓦片服务器链接加载
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489995&idx=1&sn=ff69ac95f88f1b331b058d18fffc8dae&scene=21#wechat_redirect)

[ 上海疫情开源可视化平台（含数据资源）：来自上海交通大学数字化管理决策实验室
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489833&idx=1&sn=b852395492f6f138ddf5bb35c32992b2&scene=21#wechat_redirect)

[ 全球推文地图：一个大家可能感兴趣的数据资源。
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489829&idx=1&sn=8c776f38f377fb134164e8018ef3d418&scene=21#wechat_redirect)

[ 开放铁路地图（OpenRailwayMap）网站：一个用于创建世界铁路基础设施的地图
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489820&idx=1&sn=baa49895bb9ec1cd1b29a1539dc4261a&scene=21#wechat_redirect)

[ 全球报纸地图（Newspaper Map）资源网站
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489692&idx=1&sn=293c14c3176752dcd834047f7f4be2e2&scene=21#wechat_redirect)

[ 数据资源网站IGISMAP，数据资源丰富，需要的自取。
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489680&idx=1&sn=f8dd9c05846e4d44ecc45ca5a96fa424&scene=21#wechat_redirect)

[ 这份数据资源网站，我也不知道有多少个链接。
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489645&idx=1&sn=9b76aaf8c720cff247fcc355dd204892&scene=21#wechat_redirect)

[ 猴痘病毒全球传播地图
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489632&idx=1&sn=6324daf88f454b4d4877fa9f0a4fc2ca&scene=21#wechat_redirect)

[ 全球农业（谷物、油籽、棉布等）数据资源下载地址
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489621&idx=1&sn=142fefa4266d5952dd9d9593e25501f7&scene=21#wechat_redirect)

[ 代码和数据：地理空间人工智能 (GeoAI)的十个项目案例
](https://mp.weixin.qq.com/s?__biz=MzIyMTE1MzMwOA==&mid=2247489585&idx=1&sn=ad435b223be0e3ee7b3f823b76bd2085&scene=21#wechat_redirect)  

  

** ** 需要了解更多的话，进入 **GISer last的公众号** ，选择一篇数据分享的推文，点击进入后，即可看到 ** 数据分享 及
数据分享及下载教程  ** 。点击即可浏览相关数据资源了。  

  

![](https://mmbiz.qpic.cn/mmbiz_png/M98NicsEqGhg9Gib0CiaAVSRb2khtumabjtlZgiasdWj5rPuMFg0KG0xkO3OoQDFug61Nrwr6tYV9fKpzLvibaflwew/640?wx_fmt=png)

  

最后提醒大家一句，公众号分享的数据资源，如果关键词过期了，或者链接失效了。需要集赞15个以上，截图发到公众号后台，我看到后会把数据链接重新发送。如果没有48小时内没有收到，请到QQ群里联系我。  

也非常感谢各位的关注和支持，GISer last号主会继续努力，继续推送、搬运和分享相关的数据资源和gis技术，希望大家都能有所收获。

预览时标签不可点

微信扫一扫  
关注该公众号





****



****



  收藏

